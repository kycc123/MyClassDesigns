package com.zkc.service;


import java.util.List;

import com.zkc.entity.Books;



public interface Iservice {

	public List<Books> findAllBooks();
	public Books findById(long id);
	public List<Books> findByName(String name);
	public void save(Books books);
	public void deleteBookList(List<Books> bookslist);
    public void deleteBooks(Books books);

}
