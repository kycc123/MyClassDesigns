package com.zkc.service;


import java.util.List;

import com.zkc.entity.Books;
import com.zkc.entity.BooksDAO;


public class Service implements Iservice{

	
	private BooksDAO booksDao;
    private List<Books> list;
	private Books books;

    
    
    
	public void setBooksDao(BooksDAO booksDao) {
		this.booksDao = booksDao;
	}

  

	@Override
	public List<Books> findAllBooks() {
		
		list=booksDao.findAll();
		return list;
	}



	@Override
	public Books findById(long id) {
		
		Books books = booksDao.findById(id);
		
		return books;
		
	}



	@Override
	public void save(Books book) {
		booksDao.save(book);
		
	}





	@Override
	public List<Books> findByName(String name) {
		List<Books> bookslist=booksDao.findByName(name);
		return bookslist;
	}



	@Override
	public void deleteBookList(List<Books> bookslist) {
		
		System.out.println("Service");
		for(Books books:bookslist){
			booksDao.delete(books);
		}
		
		
		
	}



	@Override
	public void deleteBooks(Books books) {
		booksDao.delete(books);
		
	}



	
	
	
	
}
