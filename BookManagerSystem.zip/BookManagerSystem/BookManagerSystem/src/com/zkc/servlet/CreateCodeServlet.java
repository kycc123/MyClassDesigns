package com.zkc.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CreateCodeServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String s="123456abcdefghijklmn";
		
		StringBuffer buffer=new StringBuffer();
		
		
		
		for(int i=0;i<4;i++){
			
			buffer.append(s.charAt((int) (Math.random()*20)));
		}
		
		req.setAttribute("validatecode", buffer.toString());
		req.getRequestDispatcher("login.jsp").forward(req, resp);
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
	}

	
	
	
}
