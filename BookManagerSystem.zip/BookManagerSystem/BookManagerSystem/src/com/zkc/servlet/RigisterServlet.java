package com.zkc.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

public class RigisterServlet extends HttpServlet {

	private Map<String, Object> session;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String ucode=new String(req.getParameter("ucode").getBytes("iso-8859-1"),"utf-8");
		String upass=new String(req.getParameter("upass").getBytes("iso-8859-1"),"utf-8");
		HttpSession session=ServletActionContext.getRequest().getSession();
		
		if(session.getAttribute("ucodelist")==null){
			List<String> ucodelist=new ArrayList<String>();
			List<String> upasslist=new ArrayList<String>();
			System.out.println("RigisterServlet ucode"+ucode);
			ucodelist.add(ucode);
			upasslist.add(upass);
			session.setAttribute("ucodelist", ucodelist);
			session.setAttribute("upasslist", upasslist);
		}else{
			
			List<String> ucodelist=(List<String>) session.getAttribute("ucodelist");
			List<String> upasslist=(List<String>) session.getAttribute("upasslist");
			ucodelist.add(ucode);
			upasslist.add(upass);
			session.setAttribute("ucodelist", ucodelist);
			session.setAttribute("upasslist", upasslist);
		}
		
		req.getRequestDispatcher("/create.do").forward(req, resp);
	
		
	}


	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
	
	}

	
	
	
	
}
