package com.zkc.action;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;

import com.zkc.entity.Books;
import com.zkc.service.Iservice;

public class UpdateAction implements ServletRequestAware,SessionAware{

	private Iservice service;
	private HttpServletRequest httpServletRequest;
	private Map<String, Object> session;

	
	

	public void setService(Iservice service) {
		this.service = service;
	}
	public String beforeUpdate(){
		String name=null;
		try {
			name = new String(httpServletRequest.getParameter("name").getBytes("iso-8859-1"),"utf-8");
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		List<Books> bookslist=service.findByName(name);
	    int booksize=bookslist.size();
		if(booksize>0){
			httpServletRequest.setAttribute("booksnumber",booksize);
			service.deleteBookList(bookslist);
			return "success";
		}
		else{
			return "update-fail";
		}
		
	}
	public String update(){
		
		String name=null;
		String price=null;
		String author=null;
		String publisher=null;
		try {
			name = new String(httpServletRequest.getParameter("name").getBytes("iso-8859-1"),"utf-8");
			price=new String(httpServletRequest.getParameter("price").getBytes("iso-8859-1"),"utf-8");
			author=new String(httpServletRequest.getParameter("author").getBytes("iso-8859-1"),"utf-8");
			publisher=new String(httpServletRequest.getParameter("publisher").getBytes("iso-8859-1"),"utf-8");
		} catch (UnsupportedEncodingException e) {
			
			e.printStackTrace();
		}
		System.out.println(httpServletRequest);
		int booksnumber=(Integer) session.get("booksnumber");
		
		for(int i=0;i<booksnumber;i++){
				Books newbooks=new Books();
				newbooks.setName(name);
				newbooks.setPrice(Double.parseDouble(price));
				newbooks.setAuthor(author);
				newbooks.setPublisher(publisher);
				service.save(newbooks);
		}
	           
	        List<Books> booksListAfterUpdate=service.findAllBooks();
			httpServletRequest.setAttribute("booklist",booksListAfterUpdate);
			
			return "success";
		
		
		
	}

	@Override
	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.httpServletRequest=httpServletRequest;
		
	}
	@Override
	public void setSession(Map<String, Object> session) {
		this.session=session;
		
	}
	
	
}
