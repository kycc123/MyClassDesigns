package com.zkc.action;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.zkc.entity.Books;
import com.zkc.service.Iservice;

public class DeleteAction implements ServletRequestAware{

	private Iservice service;
	private HttpServletRequest httpServletRequest;
	
	
	public void setService(Iservice service) {
		this.service = service;
	}


	public String delete(){
		System.out.println("delete����ǰ");
		String name=null;
		try {
			name = new String(httpServletRequest.getParameter("name").getBytes("iso-8859-1"),"utf-8");
		} catch (UnsupportedEncodingException e) {
	
			e.printStackTrace();
		}
		
		List<Books> bookslist=service.findByName(name);
		System.out.println("delete������");
		System.out.println("bookslist"+bookslist);
		if(bookslist.size()>0){
			service.deleteBookList(bookslist);
			List<Books> bookslist2=service.findAllBooks();
			
			httpServletRequest.setAttribute("bookslist2", bookslist2);
			return "success";
		}else{
            List<Books> bookslist2=service.findAllBooks();
			httpServletRequest.setAttribute("bookslist2", bookslist2);
			return "fail";
		}
		
	
	}


	@Override
	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.httpServletRequest=httpServletRequest;
		
	}
	
}
