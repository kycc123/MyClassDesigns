package com.zkc.action;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;


import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;


import com.zkc.entity.Books;
import com.zkc.service.Iservice;

public class AddAction implements ServletRequestAware{

	private Iservice service;
	private HttpServletRequest httpServletRequest;

	

	public void setService(Iservice service) {
		this.service = service;
	}
	
	
	public String findBooksAgain(){
		List<Books> books=new ArrayList<Books>();
		books=service.findAllBooks();
	    httpServletRequest.setAttribute("booklist", books);
		return "success";
	}
	
	
	public String add(){
		Books books=new Books();
		String name=null;
		String price=null;
		String author=null;
		String publisher=null;
		try {
			name = new String(httpServletRequest.getParameter("name").getBytes("iso-8859-1"),"utf-8");
			price=new String(httpServletRequest.getParameter("price").getBytes("iso-8859-1"),"utf-8");
			author=new String(httpServletRequest.getParameter("author").getBytes("iso-8859-1"),"utf-8");
			publisher=new String(httpServletRequest.getParameter("publisher").getBytes("iso-8859-1"),"utf-8");
		} catch (UnsupportedEncodingException e) {
			
			e.printStackTrace();
		}
		books.setName(name);
		books.setPrice(Double.parseDouble(price));
		books.setAuthor(author);
		books.setPublisher(publisher);
		service.save(books);
		return findBooksAgain();
	}

	@Override
	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.httpServletRequest=httpServletRequest;
		
	}


	


	




	

	


	



	
}
