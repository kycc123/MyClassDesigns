package com.zkc.action;

 
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;







import com.zkc.entity.Books;
import com.zkc.service.Iservice;
import com.zkc.service.Service;


public class ValidateAction implements ServletRequestAware,SessionAware{

    HttpServletRequest httpServletRequest;
    Map<String, Object> session;

    private Iservice service;
    
    
	public void setService(Service service) {
		this.service = service;
	}

	@Override
	public void setServletRequest(HttpServletRequest httpServletRequest){
		this.httpServletRequest=httpServletRequest;
		
	}
	
	@Override
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
		this.session=session;
	}
	
	
	
	
	public String validate(){
		
		String username=httpServletRequest.getParameter("ucode");
		String password=httpServletRequest.getParameter("upass");
		String validatecode=httpServletRequest.getParameter("validatecode");
		Boolean flag=false;
	    
		String sessionvalue=(String) session.get("validatecode");
	    
		HttpSession httpsession=ServletActionContext.getRequest().getSession();
		List<String> ucodelist=(List<String>) httpsession.getAttribute("ucodelist");
		List<String> upasslist=(List<String>) httpsession.getAttribute("upasslist");
	   
		int ucodejudge=0;
		int upassjudge=0;
		
		if(ucodelist==null||upasslist==null){
			return "fail";
		}
		
 		
		System.out.println("ucodelist"+ucodelist.size());
		System.out.println("ucode 0"+ucodelist.get(0));
		
		for(int i=0;i<ucodelist.size();i++){
			System.out.println("ucode"+ucodelist.get(i));
	    	System.out.println("upass"+upasslist.get(i));
	    	
			if(username.equals(ucodelist.get(i))){
				ucodejudge=1;
				System.out.println("validate ucode");
			   }
			else{
				ucodejudge=0;
				continue;
			}	
			if(password.equals(upasslist.get(i))){
				System.out.println("validate upass");
				upassjudge=1;
				break;
			}
			else{
				upassjudge=0;
			}
	    }
		    if(ucodejudge==1){
			flag=true;
			System.out.println("�д��û�");
		   }else{
	        return "fail";
		   }
		
		if(upassjudge==1){
			
			flag=true;
		}else{
			
			 return "fail";
		}
		
		if(validatecode.equals(sessionvalue)){
			
			flag=true;
		}else{
			 return "fail";
		}
		
		if(flag){
		List<Books> list=new ArrayList<Books>();
		list=service.findAllBooks();
		httpServletRequest.setAttribute("booklist", list);
			
		 return "success";
		}
		else{
		 return "fail";
		}
		
		
		
	}

	

	

	
	

	
	
	


}
