package com.zkc.action;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.zkc.entity.Books;
import com.zkc.service.Iservice;

public class SelectAction implements ServletRequestAware{

	private Iservice service;
	private HttpServletRequest httpServletRequest;


	public void setService(Iservice service) {
		this.service = service;
	}
	
	public String select(){
		String name=null;
		try {
			name = new String(httpServletRequest.getParameter("name").getBytes("iso-8859-1"),"utf-8");
		} catch (UnsupportedEncodingException e) {
	
			e.printStackTrace();
		}
		
		List<Books> bookslist=service.findByName(name);
	
		System.out.println("bookslist"+bookslist);
		if(bookslist.size()>0){
		
			httpServletRequest.setAttribute("bookslist", bookslist);
			return "success";
		}else{
			return "fail";
		}
	
	
	
	}

	@Override
	public void setServletRequest(HttpServletRequest httpServletRequest) {
		
		this.httpServletRequest=httpServletRequest;
	}
}
