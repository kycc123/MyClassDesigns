package com.zkc.entity;

/**
 * Books entity. @author MyEclipse Persistence Tools
 */
public class Books extends AbstractBooks implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Books() {
	}

	/** full constructor */
	public Books(String name, Double price, String author, String publisher,
			Integer counts, String path) {
		super(name, price, author, publisher, counts, path);
	}

}
