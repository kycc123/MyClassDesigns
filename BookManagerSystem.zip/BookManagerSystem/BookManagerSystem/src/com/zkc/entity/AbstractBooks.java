package com.zkc.entity;

/**
 * AbstractBooks entity provides the base persistence definition of the Books
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractBooks implements java.io.Serializable {

	// Fields

	private Long id;
	private String name;
	private Double price;
	private String author;
	private String publisher;
	private Integer counts;
	private String path;

	// Constructors

	/** default constructor */
	public AbstractBooks() {
	}

	/** full constructor */
	public AbstractBooks(String name, Double price, String author,
			String publisher, Integer counts, String path) {
		this.name = name;
		this.price = price;
		this.author = author;
		this.publisher = publisher;
		this.counts = counts;
		this.path = path;
	}

	// Property accessors

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getPrice() {
		return this.price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getAuthor() {
		return this.author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublisher() {
		return this.publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public Integer getCounts() {
		return this.counts;
	}

	public void setCounts(Integer counts) {
		this.counts = counts;
	}

	public String getPath() {
		return this.path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	@Override
	public String toString() {
		return "AbstractBooks [name=" + name + "]";
	}

	
}